<?php if($errors->any()): ?>

<div class="alert alert-danger">

    <ul>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

</div>

<?php endif; ?>



<?php if(session('status')): ?>

<div class="body">
<div class="alert alert-success" style="text-align: center;">
    <?php echo e(session('status')); ?>

</div>
</div>

<?php endif; ?>

<?php if(session('error')): ?>
<div class="body">
<div class="alert alert-danger" style="text-align: center;">
    <?php echo e(session('error')); ?>

</div>
</div>
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/survey/resources/views/messages.blade.php ENDPATH**/ ?>