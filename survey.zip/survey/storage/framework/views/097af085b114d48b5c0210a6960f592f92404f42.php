<?php $__env->startSection('content'); ?>



<div class="container">
    <div class="over">
        <h1> survey </h1>
        <?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(url('/saveCity')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
    <div class="row">

        <div class="col-md-12">
            <div class="q1">
                <div class="box">
                    <h2> question 1 </h2>
                    <h2> Did you put a cancelation request because you have a MOP?</h2>
                    <ul>
                        <li id="op1"> yes </li>
                        <li id="op2"> no </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="q1-1">
                <div class="box">
                    <h2> question 1-1 </h2>
                    <h2>what is the main reason to disconnect the line ? </h2>
                    <ul>
                            <div  id="op1" class="form-check">
                                <input class="form-check-input" type="checkbox" name="q1-1" id="exampleRadios1" value="Frequent Technical issues">
                                <label class="form-check-label" for="exampleRadios1">
                                    Frequent Technical issues
                                </label>
                              </div>

                              <div id="op2" class="form-check">
                                <input class="form-check-input" type="checkbox" name="q1-1" id="exampleRadios1" value="Better offer from Competitor" >
                                <label class="form-check-label" for="exampleRadios1">
                                    Better offer from Competitor
                                </label>
                              </div>
                              <div id="op3" class="form-check">
                                <input class="form-check-input" type="checkbox" name="q1-1" id="exampleRadios1" value="No Usage" >
                                <label class="form-check-label" for="exampleRadios1">
                                    No Usages
                                </label>
                              </div>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="q1-1-text">
                <div class="box">
                    <h2> </h2>
                    <h2>comment  :  </h2>
                   <textarea name="q1-comment"></textarea>
                </div>
                <span id="next"> next </span>
            </div>
        </div>
        

        <div class="col-md-12">
            <div class="q2">
                <div class="box">
                    <h2> question 2 </h2>
                    <h2> Which area did you move to? </h2>
                    <p>from</p>
                        <select name="city-from" class="form-control" id="exampleFormControlSelect1" >
                        <option> riyadh </option>
                        <option> jeddah </option>
                        <option> dammam </option>
                        <option> madinah </option>
                    </select>
                    <p>distrec</p>
                    <input type="text" name="dist-from" class="form-control" >
                    <p>to</p>
                    <select name="city-to" class="form-control" id="exampleFormControlSelect1" >
                        <option> riyadh </option>
                        <option> jeddah </option>
                        <option> dammam </option>
                        <option> madinah </option>
                    </select>
                    <p>distrec</p>
                    <input type="text" name="dist-to" class="form-control">
                 </div>
                 <span id="submit"> next </span>
            </div>
        </div>

        

        <div class="col-md-12">
            <div class="q3">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> why you didn’t take your line with you? </h2>
                    <ul>
                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q3" id="exampleRadios1" value=" I'm not aware that I can take it">
                            <label class="form-check-label" for="exampleRadios1">
                                I'm not aware that I can take it
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q3" id="exampleRadios1" value=" No cabinet Available in the New Area">
                            <label class="form-check-label" for="exampleRadios1">
                                No cabinet Available in the New Area
                            </label>
                          </div>
                          <div  id="op3" class="form-check">
                            <input class="form-check-input" type="radio" name="q3" id="exampleRadios1" value="ive got a replacement">
                            <label class="form-check-label" for="exampleRadios1">
                                ive got a replacement
                            </label>
                          </div>
                          <div  id="op4" class="form-check">
                            <input class="form-check-input" type="radio" name="q3" id="exampleRadios1" value="STC outlet told me to take a new buttonne">
                            <label class="form-check-label" for="exampleRadios1">
                                STC outlet told me to take a new buttonne
                            </label>
                          </div>
                          <div  id="op5" class="form-check">
                            <input class="form-check-input" type="radio" name="q3" id="exampleRadios1" value="STC Call Center informed me to take new buttonne">
                            <label class="form-check-label" for="exampleRadios1">
                                STC Call Center informed me to take new buttonne
                            </label>
                          </div>
                          <div  id="op6" class="form-check">
                            <input class="form-check-input" type="radio" name="q3" id="exampleRadios1" value="other">
                            <label class="form-check-label" for="exampleRadios1">
                                other
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="q3-1">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> when you applied for cancellation were you infomred that you can take your line?</h2>
                    <ul>

                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-1" id="exampleRadios1" value="yes">
                            <label class="form-check-label" for="exampleRadios1">
                                yes
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-1" id="exampleRadios1" value="no">
                            <label class="form-check-label" for="exampleRadios1">
                                no
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="q3-2">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> Are you aware about our jood wireless product which gives you internet wihtout cabinet out side your house? </h2>
                    <ul>
                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-2" id="exampleRadios1" value="yes">
                            <label class="form-check-label" for="exampleRadios1">
                                yes
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-2" id="exampleRadios1" value="no">
                            <label class="form-check-label" for="exampleRadios1">
                                no
                            </label>
                          </div>
                          <div  id="op3" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-2" id="exampleRadios1" value="no coverage">
                            <label class="form-check-label" for="exampleRadios1">
                                no coverage
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="q3-2-1">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> would you like to take a jood wireless from STC that offers you excellent internet service without any cabinet?  </h2>
                    <ul>
                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-2-1" id="exampleRadios1" value="yes">
                            <label class="form-check-label" for="exampleRadios1">
                                yes
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-2-1" id="exampleRadios1" value="no">
                            <label class="form-check-label" for="exampleRadios1">
                                no
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="q3-3">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> From Which Service Provider did you get another line? </h2>
                    <ul>
                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3" id="exampleRadios1" value="mobile">
                            <label class="form-check-label" for="exampleRadios1">
                                mobile
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3" id="exampleRadios1" value="zain">
                            <label class="form-check-label" for="exampleRadios1">
                                zain
                            </label>
                          </div>
                          <div  id="op3" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3" id="exampleRadios1" value="go">
                            <label class="form-check-label" for="exampleRadios1">
                                go
                            </label>
                          </div>
                          <div  id="op4" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3" id="exampleRadios1" value="stc">
                            <label class="form-check-label" for="exampleRadios1">
                                stc
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="q3-3-1">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> What is the STC Offer /service that you are using?</h2>
                    <ul>
                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3-1" id="exampleRadios1" value="Land buttonne DSL/FTTH">
                            <label class="form-check-label" for="exampleRadios1">
                                Land buttonne DSL/FTTH
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3-1" id="exampleRadios1" value="Mobile">
                            <label class="form-check-label" for="exampleRadios1">
                                Mobile
                           </label>
                          </div>
                          <div  id="op3" class="form-check">
                            <input class="form-check-input" type="radio" name="q3-3-1" id="exampleRadios1" value="router / on the go">
                            <label class="form-check-label" for="exampleRadios1">
                                router / on the go
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="q3-6">
                <div class="box">
                    <h2> question 3</h2>
                    <h2> reasons :  </h2>
                    <textarea rows="3" name="q3-6"></textarea>
                </div>
                <span id="next"> next </span>
            </div>
        </div>



        



        <div class="col-md-12">
            <div class="q4">
                <div class="box">
                    <h2> question 4 </h2>
                    <h2>Would you buttonke to reactivate you earbuttoner buttonne with STC ? </h2>
                    <ul>
                        <div  id="op1" class="form-check">
                            <input class="form-check-input" type="radio" name="q4" id="exampleRadios1" value="yes">
                            <label class="form-check-label" for="exampleRadios1">
                                yes
                            </label>
                          </div>
                          <div  id="op2" class="form-check">
                            <input class="form-check-input" type="radio" name="q4" id="exampleRadios1" value="no">
                            <label class="form-check-label" for="exampleRadios1">
                                no
                            </label>
                          </div>
                    </ul>
                </div>
            </div>
        </div>

            <div class="col-md-12">
                <div class="q4-1">
                    <div class="box">
                        <h2> question 4 </h2>
                        <h2>What would be the most appropriate time to call you? </h2>
                        <ul>
                            <div  id="op1" class="form-check">
                                <input class="form-check-input" type="radio" name="q4-1" id="exampleRadios1" value="yes">
                                <label class="form-check-label" for="exampleRadios1">
                                    yes
                                </label>
                              </div>
                              <div  id="op2" class="form-check">
                                <input class="form-check-input" type="radio" name="q4-1" id="exampleRadios1" value="no">
                                <label class="form-check-label" for="exampleRadios1">
                                    no
                                </label>
                              </div>
                       </ul>
                    </div>
                </div>
            </div>

                <div class="col-md-12">
                    <div class="q4-1-1">
                        <div class="box">
                            <h2> question 4 </h2>
                            <h2>What would be the most appropriate time to call you? </h2>
                        <input type="month" id="date" name="q4-1-1" min="2019-01" max="2024-12">
                        </div>
                        <span id="next"> next </span>
                    </div>
                </div>

            <div class="col-md-12 done">
                <div class="done">
                    <div class="box">
                        <h2> thank you </h2>
                        <input type="submit" value="send" class="button">
                    
                   </div>
                </div>
            </div>

    </div>
</form>

</div>
</div>

<script href="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
$(document).ready(function(){

    // question 1

    $(".q1 #op1").click(function(){
        $(".q2").css("display", "block");
        $(".q1").css("display", "none");
    });
    $(".q1 #op2").click(function(){
        $(".q1-1").css("display", "block");
        $(".q1").css("display", "none");
    });
    $(".q1-1 #op3").click(function(){
        $(".q1-1-text").css("display", "block");
        $(".q1-1").css("display", "none");
    });
    $(".q1-1 #op2 , .q1-1 #op1").click(function(){
        $(".q2").css("display", "block");
        $(".q1-1").css("display", "none");
    });

//   question 2

$("#submit").click(function(){
        $(".q2").css({"display": "none","position":"absolute" , "left":"-11000px"});
        // $(".q2").hide();
        $(".q3").css("display", "block");
    });

    // question 3 - 1

    $(".q3 #op1").click(function(){
        $(".q3").css("display", "none");
        $(".q3-1").css("display", "block");
    });
    $(".q3-1 #op1 , .q3-1 #op1").click(function(){
        $(".q3-1").css("display", "none");
        $(".q4").css("display", "block");
    });
  // question 3 -2

  $(".q3 #op2").click(function(){
        $(".q3").css("display", "none");
        $(".q3-2").css("display", "block");
    });

    $(".q3-2 #op1 , .q3-2 #op3 ").click(function(){
        $(".q3-2").css("display", "none");
        $(".q3-2-1").css("display", "block");
    });

    $(".q3-2 #op2").click(function(){
        $(".q3-2").css("display", "none");
        $(".q3-2-1").css("display", "block");
    });
    $(".q3-2-1 #op2 , .q3-2-1 #op1").click(function(){
        $(".q3-2-1").css("display", "none");
        $(".q4").css("display", "block");
    });

    // question 3 -3
    $(".q3 #op3").click(function(){
        $(".q3").css("display", "none");
        $(".q3-3").css("display", "block");
    });
    $(".q3-3 #op4").click(function(){
        $(".q3-3").css("display", "none");
        $(".q3-3-1").css("display", "block");
    });
    $(".q3-3 #op1 , .q3-3 #op2 , .q3-3 #op3").click(function(){
        $(".q3-3").css("display", "none");
        $(".q4").css("display", "block");
    });

    //question 3-4 , 3-5

    $(".q3 #op4 , .q3 #op5").click(function(){
        $(".q3").css("display", "none");
        $(".q4").css("display", "block");
    });

    // question 3-6

    $(".q3 #op6").click(function(){
        $(".q3").css("display", "none");
        $(".q3-6").css("display", "block");
    });


    //question 4

    $(".q4 #op1").click(function(){
        $(".q4").css("display", "none");
        $(".q4-1").css("display", "block");
    });

    $(".q4 #op2").click(function(){
        $(".q4").css("display", "none");
        $(".done").css("display", "block");
    });


    $(".q4-1 #op1").click(function(){
        $(".q4-1").css("display", "none");
        $(".q4-1-1").css("display", "block");
    });

    $(".q4-1 #op2").click(function(){
        $(".q4-1").css("display", "none");
        $(".done").css("display", "block");
    });


    //done

    $("span#next").click(function(){
        $(".q1-1-text , .q3-6 , .q4-1-1").css("display", "none");
        $(".done").css("display", "block");
    });

});

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/survey/resources/views/survey.blade.php ENDPATH**/ ?>