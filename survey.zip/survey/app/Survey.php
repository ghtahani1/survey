<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Survey extends Authenticatable
{
    // use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'city-from','dist-from','dist-to','city-to','q1','q1-1','q1-comment','q3','q3-1','q3-2','q3-2-1','q3-3','q3-3-1','q3-6'
        ,'q4','q4-1','q4-1-1'
    ];


}
