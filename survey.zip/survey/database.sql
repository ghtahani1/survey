-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 17, 2021 at 01:35 PM
-- Server version: 5.6.38
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `survey`
--

-- --------------------------------------------------------

--
-- Table structure for table `surveys`
--

CREATE TABLE `surveys` (
  `id` bigint(55) NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL,
  `city-from` varchar(255) DEFAULT NULL,
  `city-to` varchar(255) DEFAULT NULL,
  `dist-from` varchar(255) DEFAULT NULL,
  `dist-to` varchar(255) DEFAULT NULL,
  `q1-1` varchar(255) DEFAULT NULL,
  `q1-comment` varchar(255) DEFAULT NULL,
  `q3` varchar(255) DEFAULT NULL,
  `q3-1` varchar(255) DEFAULT NULL,
  `q3-2` varchar(255) DEFAULT NULL,
  `q3-2-1` varchar(255) DEFAULT NULL,
  `q3-3` varchar(255) DEFAULT NULL,
  `q3-3-1` varchar(255) DEFAULT NULL,
  `q3-6` varchar(255) DEFAULT NULL,
  `q4` varchar(255) DEFAULT NULL,
  `q4-1` varchar(255) DEFAULT NULL,
  `q4-1-1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `surveys`
--
ALTER TABLE `surveys`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `surveys`
--
ALTER TABLE `surveys`
  MODIFY `id` bigint(55) NOT NULL AUTO_INCREMENT;
